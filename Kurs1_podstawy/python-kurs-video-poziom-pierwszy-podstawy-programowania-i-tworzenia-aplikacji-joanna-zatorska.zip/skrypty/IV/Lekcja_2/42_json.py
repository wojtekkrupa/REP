'''
JSON
'''

import urllib.parse as up
import urllib.request as ur
import json

url='http://pl.wikipedia.org/w/api.php'
dane={'action':'query','list':'categorymembers','cmtitle':'Category:Python','format':'json'}
url_pelny=url+'?'+up.urlencode(dane)
#print(url_pelny)
odp=ur.urlopen(url_pelny)
str_odp=odp.readall().decode('utf-8')
odp.close()
#print(str_odp)
js=json.loads(str_odp)
print(js['query']['categorymembers'])
for strona in js['query']['categorymembers']:
    print(strona['title'])


