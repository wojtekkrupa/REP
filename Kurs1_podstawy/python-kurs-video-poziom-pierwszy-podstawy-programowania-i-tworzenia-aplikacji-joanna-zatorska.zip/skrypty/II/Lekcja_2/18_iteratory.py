'''
Iteratory
'''

lista=[2,3,6,2]

iterator=iter(lista)
print(iterator)
'''
print(iterator.__next__())
print(next(iterator))
print(next(iterator))
print(next(iterator))
print(next(iterator))
'''

print(next(lista))