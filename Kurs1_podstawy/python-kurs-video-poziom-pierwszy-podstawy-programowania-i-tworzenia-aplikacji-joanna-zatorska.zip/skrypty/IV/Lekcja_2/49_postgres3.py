
'''
Postgres
'''

import psycopg2

connection=psycopg2.connect("host=localhost dbname=kurs_pythona user=postgres password=haslo")
kursor=connection.cursor()
cena=50
kursor.execute("SELECT tytul FROM ksiazki WHERE cena<%(cena)s",(cena,))
dane=kursor.fetchall()
#print(dane)

for r in dane:
    print(r)

kursor.close()
connection.close()