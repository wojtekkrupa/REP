'''
Napisy zaawansowane
'''


napis="Wiek: "+str(18)

print(napis)

#print(napis.replace("W","w"))

#print(napis.lower())

#print(napis.upper())

napis="Ta liczba %f to %s" % (3.23, "liczba")

print(napis)






