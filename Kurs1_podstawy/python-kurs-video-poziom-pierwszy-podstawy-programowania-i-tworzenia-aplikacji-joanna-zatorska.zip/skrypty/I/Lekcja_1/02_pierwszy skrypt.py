napis="Zielony jak Python"
print(napis)
a, b, c=1,2,3
print(a)
