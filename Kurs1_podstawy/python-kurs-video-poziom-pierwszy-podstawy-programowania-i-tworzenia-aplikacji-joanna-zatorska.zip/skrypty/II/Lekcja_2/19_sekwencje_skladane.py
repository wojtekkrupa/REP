'''
Sekwencje składane
'''
'''
lista=[a * 5 for a in (1,2,3)]

print(lista)

lista=[]
for a in (1,2,3):
    lista.append(a*5)

print(lista)


krotki=[(a, a+1) for a in (1,2,3) ]
print(krotki)
'''

slownik={a:a+1 for a in [1,2,3]}
print(slownik)