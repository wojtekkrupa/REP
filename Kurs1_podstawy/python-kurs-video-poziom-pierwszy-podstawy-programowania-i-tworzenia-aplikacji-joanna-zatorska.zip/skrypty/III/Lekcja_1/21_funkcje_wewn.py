'''
Funkcje wewnętrzne
'''
'''
def funkcja1(a):
    print(a)
    def funkcja2():
        print(a*2)
    funkcja2()

funkcja1(5)


def oblicz(a,b):
    print(a*b)

test=oblicz
test(2,3)
'''
a=4

if a<5:
    def funkcja():
        print('mniejsza od 5')
else:
    def funkcja():
        print('większa lub rowna 5')

funkcja()