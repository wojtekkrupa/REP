'''
Obsługa plikow - cd.
'''

plik=open('C:\\Users\\python\\Desktop\\Python\\Obsługa plików\\plik.txt', 'w')

a=plik.write('Przykładowy tekst')
plik.close()

print(a)

plik=open('C:\\Users\\python\\Desktop\\Python\\Obsługa plików\\plik.txt', 'a')

plik.write('\nDrugi wiersz\n')
plik.close()

with open ('C:\\Users\\python\\Desktop\\Python\\Obsługa plików\\plik.txt','r') as f:
    print(f.read())

