'''
Liczbowe typy danych
'''

calkowita=10
print(calkowita)

zmiennoprzecinkowa=10.123
print(zmiennoprzecinkowa)
b=2E-7
print(b)
c=2.
print(c)

zespolona=3+5j
print(zespolona)

osemkowa=0o15
print(osemkowa)

szesnastkowa=0xabc
print(szesnastkowa)

dwojkowa=0b1011
print(dwojkowa)


