'''
Listy wielowymiarowe
'''

macierz=[1,[1,2,3,4]]
print(macierz)

print(macierz[1][3])

macierz[1][3]=5
print(macierz)

macierz[1][4]=5
