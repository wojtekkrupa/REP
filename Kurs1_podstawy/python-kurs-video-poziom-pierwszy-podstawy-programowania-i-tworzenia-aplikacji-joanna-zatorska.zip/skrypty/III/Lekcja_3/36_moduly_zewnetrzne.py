'''
Moduły zewnętrzne
'''

from PIL import Image

obraz=Image.open('C:\\Users\\python\\Desktop\\Python\\Moduły\\obraz.jpg')
obraz.show()