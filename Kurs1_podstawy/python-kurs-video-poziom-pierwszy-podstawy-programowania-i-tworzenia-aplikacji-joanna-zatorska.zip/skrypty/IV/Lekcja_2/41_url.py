'''
Otwieranie URL
'''

import urllib.request as ur
import urllib.parse as up

'''
odp=ur.urlopen('http://python.org')

html=odp.read()
print(html)

plik=open('C:\\Users\\python\\strona.html', 'wb')
plik.write(html)
plik.close()
'''

url='http://helion.pl/search'
dane={'szukaj':'Python','wsprzed':'1','qa':''}
url_zakodowane=up.urlencode(dane)
url_pelne=url+'?'+url_zakodowane
print(url_pelne)
odp=ur.urlopen(url_pelne)
html=odp.read()
print(html)
plik=open('C:\\Users\\python\\strona.html', 'wb')
plik.write(html)
plik.close()