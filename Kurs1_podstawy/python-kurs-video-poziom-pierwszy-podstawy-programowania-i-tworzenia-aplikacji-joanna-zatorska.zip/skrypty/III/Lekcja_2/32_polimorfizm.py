'''
Klasy
'''


class Zwierz:
    '''Pierwsza klasa Pythona'''
    rodzaj='zwierzę'
    zwierzeta={}
    def __init__(self, gatunek, wiek,predkosc):
        self.gatunek=gatunek
        self.wiek=wiek
        self.max_predkosc=predkosc
        if gatunek in Zwierz.zwierzeta:
            Zwierz.zwierzeta[gatunek]+=1
        else:
            Zwierz.zwierzeta[gatunek]=1
    def oblicz_odleglosc(self, czas):
        print(czas*self.max_predkosc)
    def wypisz_zwierzeta():
        print(Zwierz.zwierzeta)
    def __str__(self):
        return self.gatunek+' ma '+str(self.wiek)+' lat i osiąga prędkosc '+str(self.max_predkosc)+' km/h.'


class Ptak(Zwierz):
    def __init__(self, gatunek, wiek,predkosc,max_predkosc_lotu,miejsce):
        super().__init__(gatunek, wiek,predkosc)
        self.predkosc_lotu=max_predkosc_lotu
        self.miejsce=miejsce
    def przenies(self):
        if self.miejsce=='klatka':
            self.miejsce='otwarty'
        else:
            self.miejsce='klatka'
    def oblicz_odleglosc(self, czas):
        if self.predkosc_lotu==0:
            print(czas*self.max_predkosc)
        else:
            print(czas*self.predkosc_lotu)


p=Ptak('pingwin',2,3,0,'otwarty')
p1=Ptak('kos',2,2,15,'klatka')
p.oblicz_odleglosc(2)
p1.oblicz_odleglosc(2)