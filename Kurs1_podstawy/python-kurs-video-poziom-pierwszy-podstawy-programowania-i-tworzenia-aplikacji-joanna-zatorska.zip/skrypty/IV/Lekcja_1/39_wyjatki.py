'''
Wyjątki
'''
def pobierz(sekwencja, indeks):
    return sekwencja[indeks]


pliki=['C:\\Users\\python\\pliki1.txt', 'C:\\Users\\python\\_pliki2.txt']

indeks=2

try:
    p=pobierz(pliki,indeks)
    print(p)
    f=open(p)
except (IndexError, FileNotFoundError) as e:
    print('Wystąpił błąd: ',e)
else:
    print('Pobrano nazwę pliku')