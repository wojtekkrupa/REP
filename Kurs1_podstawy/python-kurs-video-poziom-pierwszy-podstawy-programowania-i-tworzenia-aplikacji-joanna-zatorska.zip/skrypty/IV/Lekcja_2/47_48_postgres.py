
from xml.etree.ElementTree import parse, dump



import psycopg2 as ps

connection=ps.connect("host=localhost dbname=kurs_pythona user=postgres password=haslo")
kursor=connection.cursor()
tree=parse('C:\\Users\\python\\asortyment.xml')
elem=tree.getroot()

for k in elem.findall('artykuł'):
    tytul=k.find('nazwa').text
    autor=k.find('autor').text
    cena=k.find('cena')
    waluta=cena.get('waluta')
    print(tytul, autor,cena.text, waluta)
    kursor.execute("INSERT INTO ksiazki (tytul, autor, cena, waluta) VALUES (%s, %s, %s, %s)",(tytul, autor,float(cena.text), waluta))
#kursor.execute("CREATE TABLE ksiazki (id serial PRIMARY KEY, tytul varchar, autor varchar, cena decimal, waluta text);")
connection.commit()
kursor.close()
connection.close()
