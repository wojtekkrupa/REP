'''
Polecenia systemowe
'''

import os

print(os.listdir("C:\\Users\\Public\\Music\\Sample Music"))

path=os.path.join(os.path.expanduser("~"), "Test")
print(path)

#os.mkdir( path, 0o777)
print(os.listdir(os.path.expanduser("~")))
path2=os.path.join(os.path.expanduser("~"), "test_")

#os.rename(path, path2)
print(os.listdir(os.path.expanduser("~")))

(katalog,plik)=os.path.split("C:\\Users\\Public\\Music\\Sample Music\\Kalimba.mp3")
print(katalog)
print(plik)
(nazwa, rozszerzenie)=os.path.splitext(plik)
print(nazwa)
print(rozszerzenie)

os.rmdir(path2)
print(os.listdir(os.path.expanduser("~")))

