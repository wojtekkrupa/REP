'''
Argumenty funkcji - cd.
'''
'''
def funkcja(**argumenty):
    print(argumenty['a'])


funkcja(a=2, c=4)


def funkcja(a,b, c=2, *args, **kargs):
    print(a,b,c,args,kargs)

funkcja(2,3,4,5,6,e=5,f=6)
'''
def funkcja(a,b,*args, c):
    print(a,b,args,c)

funkcja(1,2,3,4,c=5)