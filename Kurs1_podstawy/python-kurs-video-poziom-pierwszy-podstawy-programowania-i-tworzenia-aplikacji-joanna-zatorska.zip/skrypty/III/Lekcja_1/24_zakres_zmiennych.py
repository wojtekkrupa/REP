'''
Zakres zmiennych
'''
'''
x=5

def funkcja(a):
    global x
    x=a
    print(x)

funkcja(1)

print(x)

'''

def funkcja():
    a=5
    print(a)
    def funkcja2():
        #nonlocal a
        a=10
    funkcja2()
    print(a)

funkcja()