'''
Instrukcja if
'''
'''
if 1>2:
    print('prawda')


if True:
    print('prawda')

if 'napis':
    print('prawda')

if 0:
    print ('prawda')

if None:
    print ('prawda')


x=True
y=False

if x or y:
    print('prawda')

'''

a=-1

if a<0:
    print('ujemna')
    if a!=-20:
        print(a*2)



