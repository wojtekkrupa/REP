'''
Listy i krotki - metody wspolne
'''

k=(4,5,6,4,3)
'''
print(k.index(5))
print(k.count(4))
print(len(k))
'''
lista=[1,2,6,3]
print(lista.index(6))
print(lista.count(2))
print(len(lista))