'''
Klasy
'''


class Zwierz:
    '''Pierwsza klasa Pythona'''
    def podaj_gatunek(self):
        print('lis')


a=Zwierz()

b=Zwierz()

print(a)
print(b)

print(a==b)

a.podaj_gatunek()
b.podaj_gatunek()