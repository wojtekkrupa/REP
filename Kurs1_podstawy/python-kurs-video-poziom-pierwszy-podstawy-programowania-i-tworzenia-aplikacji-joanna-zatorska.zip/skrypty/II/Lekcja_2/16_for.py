'''
Pętla for
'''

a=['abc', [1,2,3], 1]

for i in a:
    print(i)
    for j in i:
        print(j)

'''
for i in range(len(a)):
    print(i)
'''