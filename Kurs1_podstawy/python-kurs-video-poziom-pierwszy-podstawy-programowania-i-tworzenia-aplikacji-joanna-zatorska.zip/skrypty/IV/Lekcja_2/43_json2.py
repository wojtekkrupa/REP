'''
JSON - cd.
'''

import json
'''
plik=open('C:\\Users\\python\\plik.json','r')
tresc=plik.read()

dane=json.loads(tresc)
print(dane)

for strona in dane['query']['allpages']:
    print(strona['title'])


'''

dane={}
dane['a']='ala'
dane['b']={'c':'cena',1:123}
js=json.dumps(dane)

print(js)

with open('C:\\Users\\python\\plik1.json','w') as plik:
    json.dump(dane, plik)