'''
Argumenty funkcji
'''
'''
def funkcja(a, b, c):
    print(a, b, c)

funkcja(c=2, 1, b=5)


def funkcja(a, b=2, c=5):
    print(a,b,c)
'''

def funkcja(a=3, b, c=1):
    print(a,b,c)


funkcja(2)