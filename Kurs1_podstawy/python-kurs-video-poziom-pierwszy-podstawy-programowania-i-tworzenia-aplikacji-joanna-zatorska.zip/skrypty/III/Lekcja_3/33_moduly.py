'''
Moduły
'''

import datetime

def time(a,b,c):
    print(a,b,c)

czas=datetime.time(9,25,7)
print(czas)

print(str(czas.hour)+'-'+str(czas.minute)+'-'+str(czas.second))

