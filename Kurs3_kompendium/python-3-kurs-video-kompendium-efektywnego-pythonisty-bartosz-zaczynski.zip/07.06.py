import requests
import lxml.objectify

from matplotlib.pyplot import plot


def fetch(city, country='pl'):
    api_key = '<PASTE-YOUR-API-KEY-HERE>'
    url =  f'http://api.openweathermap.org/data/2.5/forecast?mode=xml&appid={api_key}&units=metric&q={city},{country}'
    return lxml.objectify.fromstring(requests.get(url).content)


class Xml:
    def __init__(self, xml):
        self.xml = xml


class XPath:

    def __init__(self, locator, list_=False, type_=False):
        self.locator = locator
        self.list_ = list_
        self.type_ = type_

    def __get__(self, obj, cls):
        value = obj.xml.xpath(self.locator)
        if self.type_:
            value = [self.type_(x) for x in value]
        if not self.list_:
            value = value[0] if value else None
        setattr(obj, self.name, value)
        return value

    def __set_name__(self, cls, name):
        self.name = name


class XPathList(XPath):
    def __init__(self, locator, *args, **kwargs):
        super().__init__(locator, list_=True, *args, **kwargs)


class IntegerMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(type_=int, *args, **kwargs)


class FloatMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(type_=float, *args, **kwargs)


class IntegerList(IntegerMixin, XPathList):
    pass


class Integer(IntegerMixin, XPath):
    pass


class Float(FloatMixin, XPath):
    pass


class Point(Xml):

    timestamp = XPath('@from')
    temperature = Float('temperature/@value')
    humidity = Integer('humidity/@value')

    def __repr__(self):
        return f'{self.timestamp}, {self.temperature} C, {self.humidity}%'


class Forecast(Xml):
    city = XPath('//location/name')
    pressure = IntegerList('//time/humidity/@value')
    points = XPathList('//time', type_=Point)


forecast = Forecast(fetch('Krakow'))

x = range(len(forecast.points))
y = [x.temperature for x in forecast.points]
z = [x.humidity for x in forecast.points]

plot(x, y, z)
