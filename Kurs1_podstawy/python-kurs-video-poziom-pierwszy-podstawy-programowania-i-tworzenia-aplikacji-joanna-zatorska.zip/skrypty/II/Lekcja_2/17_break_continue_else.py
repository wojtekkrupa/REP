'''
Break, continue, else
'''

x=10
'''
while True:
    x+=1
    print(x)
    if x==10:
        break



while x<10:
    x+=1
    if x%2==0:
        continue
    print(x)
'''

while x<10:
    x+=1
    #if x%11==0:
    #    break
else:
    print(x)