'''
Instrukcja if - cd.
'''

#wybor=int(input('Podaj liczbę od 1-4:'))

if wybor<0:
    print('ujemna')
#elif wybor==0:
#    print('zero')
else:
    print('dodatnia')


