#!/usr/bin/env python

import array
import matplotlib.pyplot as plt

# Signed 16 bit Little Endian, Rate 44100 Hz, Mono

with open('digitar.wav', 'rb') as fp:

    fp.seek(0x28)
    num_bytes = int.from_bytes(fp.read(4), 'little')

    samples = array.array('h')
    samples.fromfile(fp, num_bytes // 2)

    plt.plot(samples)
