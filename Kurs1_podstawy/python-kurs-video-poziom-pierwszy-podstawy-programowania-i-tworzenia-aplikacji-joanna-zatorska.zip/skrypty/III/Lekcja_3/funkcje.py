'''
Własny moduł
'''

import math


def oblicz_pole_kola(r):
    return math.pi*r**2

def oblicz_obwod_kola(r):
    return math.pi*r*2