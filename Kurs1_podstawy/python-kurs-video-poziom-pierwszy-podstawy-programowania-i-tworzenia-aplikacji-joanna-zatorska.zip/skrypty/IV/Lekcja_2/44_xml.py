'''
XML
'''


from xml.etree.ElementTree import Element, SubElement, dump, ElementTree

root=Element('Asortyment')

print(root.tag)

art=SubElement(root,'artykuł',kategoria='książki')
SubElement(art,'nazwa').text='Python. Wprowadzenie'
cena=SubElement(art, 'cena')
cena.text='59'
cena.attrib['waluta']='PLN'
SubElement(art,'autor').text='Mark Lutz, David Ascher'

art=SubElement(root,'artykuł',kategoria='książki')
SubElement(art,'nazwa').text='Python. Rozmowki'
cena=SubElement(art, 'cena')
cena.text='37'
cena.attrib['waluta']='PLN'
SubElement(art,'autor').text='Brad Dayley'
dump(root)
ElementTree(root).write('C:\\Users\\python\\asortyment.xml',xml_declaration=True,encoding='utf-8',method='xml')

