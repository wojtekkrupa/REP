'''
Pętla while
'''

x=0
while x<10:
    x+=1
    print(x)
    a=1
    while a<5:
        a*=2
        print('a='+str(a))