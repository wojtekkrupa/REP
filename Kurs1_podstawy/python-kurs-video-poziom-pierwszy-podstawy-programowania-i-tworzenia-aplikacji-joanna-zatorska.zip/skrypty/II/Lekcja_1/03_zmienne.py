'''
Zmienne w Pythonie
'''

#Deklarowanie zmiennej
a=1
print(a)

a=2
print(a)


a=1+2
print(a)

a="Co się stanie?"
print(a)

#a="Wiek: "+18

print(a)

a, b, c=4, 5, 6
print(c)

a=(1, 2, 3)
(x, z, w)=a

print(w)


del(w)

#print(w)

def prosta_funkcja():
    global a
    a=15
    print(a)

print(a)
prosta_funkcja()
print(a)