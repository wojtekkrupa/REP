'''
Funkcje
'''

def wykonaj(a,b):
    print(a*b)
    return a*b


wynik=wykonaj(3,2)
print(wynik)