'''
Słowniki
'''

slownik={'a':'b','klucz':15, 3:[1,3,4]}
print(slownik)

print(slownik['a'])
print(len(slownik))

print(list(slownik.keys()))

d={}
print('b' in d)

d['b']=1
print(d)

del slownik[3]
print(slownik)

slownik.clear()
print(slownik)
