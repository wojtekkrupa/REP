'''
Boolean
'''

a=True
b=False
print(a,b)

