'''
Dane tekstowe
'''

napis='To jest\' String'
print(napis)


napis2="Tekst z tabulatorem\ti znakiem\n nowego wiersza"
print(napis2)


napis3='''wiersz o
wielu
wierszach'''

print(napis3)

print("Zielone"+" jabłko")

print("B"+"a"*5+"rdzo pyszne!")

