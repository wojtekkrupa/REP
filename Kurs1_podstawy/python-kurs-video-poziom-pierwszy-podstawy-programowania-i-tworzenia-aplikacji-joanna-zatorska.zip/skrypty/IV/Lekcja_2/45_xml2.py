'''
XML - cd.
'''

from xml.etree.ElementTree import parse, dump

tree=parse('C:\\Users\\python\\asortyment.xml')
elem=tree.getroot()
'''
dump(elem)

for i in elem.getiterator():
    dump(i)


for child in elem:
    print(child.tag, child.attrib)

'''

for k in elem.findall('artykuł'):
    tytul=k.find('nazwa').text
    cena=k.find('cena')
    waluta=cena.get('waluta')
    print(tytul, cena.text, waluta)