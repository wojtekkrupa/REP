'''
Korzystanie z własnego modułu
'''

import moj_pakiet.funkcje as f
from moj_pakiet.funkcje import oblicz_obwod_kola
pole=f.oblicz_pole_kola(4)

print(pole)

obwod=oblicz_obwod_kola(4)

print(obwod)