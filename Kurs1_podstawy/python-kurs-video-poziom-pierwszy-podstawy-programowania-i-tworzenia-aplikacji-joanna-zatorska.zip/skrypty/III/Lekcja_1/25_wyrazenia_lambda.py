'''
Wyrażenia lambda
'''
'''
l=lambda a, b, c: a+b+c

print(l(2,3,4))

def funkcja(a,b,c):
    return a+b+c

print(funkcja(2,3,4))
'''

lista=[(lambda a: a*5), (lambda a:a*6), (lambda a:a*7)]

for l in lista:
    print(l(3))


print(lista[1](3))

