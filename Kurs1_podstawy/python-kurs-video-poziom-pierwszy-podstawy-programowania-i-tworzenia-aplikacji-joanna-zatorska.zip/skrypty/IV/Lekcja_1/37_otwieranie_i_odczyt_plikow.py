'''
Obsługa plikow
'''
'''
plik=open('C:\\Users\\python\\Desktop\\Python\\Obsługa plików\\plik.txt', 'r')

tresc=plik.read()

print(tresc)

tresc=plik.read()
print(tresc)
plik.close()

print(plik.closed)


print(plik.readline())
print(plik.readline())
print(plik.readline())
plik.close()
plik=open('C:\\Users\\python\\Desktop\\Python\\Obsługa plików\\plik.txt', 'r')
for wiersz in plik:
    print(wiersz, end=' ')

plik.close()

'''

with open('C:\\Users\\python\\Desktop\\Python\\Obsługa plików\\plik.txt', 'r') as f:
    print(f.read())


plik=open('C:\\Users\\python\\Desktop\\Python\\Obsługa plików\\plik.txt', 'r')
for wiersz in plik:
    print(wiersz, end=' ')

plik.close()
